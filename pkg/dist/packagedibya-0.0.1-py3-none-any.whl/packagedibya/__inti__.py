def myfunct(number):
    '''
    This function return square of a number
    '''
    return number ** 2